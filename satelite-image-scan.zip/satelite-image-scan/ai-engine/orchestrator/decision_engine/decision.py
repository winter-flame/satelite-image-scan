from __future__ import annotations


class DecisionEngine:
    """Decide whether to accept, review, or reject a processed tile."""

    def decide(
        self,
        *,
        quality_score: float | None = None,
        degradation_score: float | None = None,
        hallucination_risk: float | None = None,
        state: dict | None = None,
    ) -> str:
        if state is not None:
            quality_score = state.get("quality_score", quality_score)
            degradation_score = state.get("degradation_score", degradation_score)
            hallucination_risk = state.get("hallucination_risk", hallucination_risk)

        if quality_score is None or degradation_score is None or hallucination_risk is None:
            raise ValueError("quality_score, degradation_score, and hallucination_risk are required")

        if quality_score >= 0.82 and degradation_score <= 0.22 and hallucination_risk <= 0.12:
            return "accept"
        if quality_score >= 0.72 and degradation_score <= 0.35 and hallucination_risk <= 0.2:
            return "review"
        return "reject"
