from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# The workflow uses a small config module loaded from the repo layout. This keeps
# the code independent from package-install assumptions while still using a real
# configuration object for stage order and thresholds.
def _load_orchestrator_config():
    config_path = Path(__file__).resolve().parents[1] / "config" / "settings.py"
    module_name = "orchestrator_config_runtime"
    spec = importlib.util.spec_from_file_location(module_name, config_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load orchestrator config from {config_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.OrchestratorConfig


OrchestratorConfig = _load_orchestrator_config()


# OrchestratorState is the in-memory state snapshot used to track a job as it
# moves through precheck, quality gate, worker dispatch, validation, and final
# decision stages.
@dataclass
class OrchestratorState:
    """Minimal mutable state for the orchestrator graph."""

    job_id: str | None = None
    status: str = "idle"
    source: str | None = None
    current_stage: str | None = None
    next_stage: str | None = None
    history: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)
    decision: str | None = None
    error: str | None = None


class OrchestratorWorkflow:
    """A small LangGraph-like workflow with explicit stages and state transitions."""

    def __init__(self, config: Any | None = None):
        # Use the repo config unless a custom config object is supplied.
        self.config = config or OrchestratorConfig()

    def start_job(self, *, job_id: str, source: str) -> OrchestratorState:
        # A new job begins in a queued state and points to the first stage in the
        # pipeline.
        state = OrchestratorState(
            job_id=job_id,
            source=source,
            status="queued",
            next_stage=self.config.stage_order[0],
        )
        self._record_event(state, "job_started", {"source": source})
        return state

    def run_stage(self, state: OrchestratorState, stage_name: str) -> OrchestratorState:
        # Validate the requested stage before mutating the state.
        if stage_name not in self.config.accepted_stages:
            raise ValueError(f"Unknown stage: {stage_name}")

        # Update the state to reflect the current stage and the next stage.
        state.current_stage = stage_name
        state.status = "running"
        state.next_stage = self._next_stage_name(stage_name)
        self._record_event(state, stage_name, {"status": "completed"})
        return state

    def _next_stage_name(self, stage_name: str) -> str | None:
        # Determine the next pipeline step in sequence.
        stage_index = self.config.stage_order.index(stage_name)
        if stage_index + 1 >= len(self.config.stage_order):
            return None
        return self.config.stage_order[stage_index + 1]

    def _record_event(self, state: OrchestratorState, stage: str, payload: dict[str, Any]) -> None:
        # Persist the stage transition as a lightweight audit trail.
        state.history.append({
            "stage": stage,
            "status": state.status,
            "payload": payload,
        })

    def finalize(self, state: OrchestratorState, decision: str) -> OrchestratorState:
        # Seal the workflow once the final decision has been made.
        state.decision = decision
        state.status = "completed"
        state.current_stage = "decision"
        state.next_stage = None
        self._record_event(state, "decision", {"decision": decision})
        return state
