from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# This helper loads sibling modules from the filesystem rather than assuming the
# package is installed as a normal Python package. That keeps the repo-friendly
# project layout working in a local dev environment.
def _load_module(module_name: str, relative_path: str):
    module_path = Path(__file__).resolve().parents[1] / relative_path
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


# Import the configuration and decision components used by the orchestrator graph.
_orchestrator_config_module = _load_module("orchestrator_config_runtime", "config/settings.py")
_quality_gate_module = _load_module("orchestrator_quality_gate_runtime", "gates/quality_gate.py")
_decision_engine_module = _load_module("orchestrator_decision_runtime", "decision_engine/decision.py")

OrchestratorConfig = _orchestrator_config_module.OrchestratorConfig
QualityGate = _quality_gate_module.QualityGate
DecisionEngine = _decision_engine_module.DecisionEngine


# Graph state holds the runtime snapshot of a tile/job while it moves through the
# AI enhancement pipeline.
@dataclass
class OrchestratorGraphState:
    job_id: str | None = None
    status: str = "idle"
    current_stage: str | None = None
    history: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, float] = field(default_factory=dict)
    decision: str | None = None


class OrchestratorGraph:
    """Real orchestration graph with routing and quality decisions."""

    def __init__(self, config: OrchestratorConfig | None = None):
        # Build the evaluation stack from the configured thresholds.
        self.config = config or OrchestratorConfig()
        self.quality_gate = QualityGate(
            quality_threshold=self.config.quality_threshold,
            degradation_threshold=self.config.degradation_threshold,
            hallucination_threshold=self.config.hallucination_threshold,
        )
        self.decision_engine = DecisionEngine()

    def evaluate(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> bool:
        # The gate decides whether the processing result is safe enough to continue.
        return self.quality_gate.evaluate(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        )

    def route_next(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> str:
        # Route clean results to the worker dispatch step; otherwise trigger a review.
        if self.evaluate(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        ):
            return "dispatch_workers"
        return "review_required"

    def decide(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> str:
        # Final policy decision: accept, review, or reject.
        return self.decision_engine.decide(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        )

    def dispatch_workers(self, metrics: dict[str, float]) -> list[str]:
        """Select only the workers whose degradation trigger is above its threshold.

        Each worker is paired to a specific degradation signal. The orchestrator
        checks that signal and invokes the worker only when the metric is above
        the configured threshold. This avoids firing every worker regardless of
        the actual problem present in the image.
        """
        selected_workers: list[str] = []

        for signal_name, value in metrics.items():
            worker_name = self.config.worker_map.get(signal_name)
            if worker_name is None:
                continue

            threshold = self.config.worker_thresholds.get(worker_name, 0.0)
            if value >= threshold:
                selected_workers.append(worker_name)

        return selected_workers

    def attach_validation_metrics(self, metrics: dict[str, float], validation_result: dict) -> dict[str, float]:
        """Expose downstream detection value separately from quality metrics."""
        updated_metrics = dict(metrics)
        updated_metrics["crater_detection_f1_delta"] = float(validation_result["f1_delta"])
        return updated_metrics
