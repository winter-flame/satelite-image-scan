# These tests exercise the orchestration control plane in a lightweight way.
# They confirm the job lifecycle, stage progression, and final quality decision
# logic behave as expected before the team adds the real worker integration.
import importlib
import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
WORKFLOW_PATH = ROOT / "ai-engine" / "orchestrator" / "graph" / "workflow.py"
GRAPH_PATH = ROOT / "ai-engine" / "orchestrator" / "graph" / "graph.py"

# Load the workflow module directly from its repo path so the tests work even
# without installing the package as a Python module.
spec = importlib.util.spec_from_file_location("orchestrator_workflow_runtime", WORKFLOW_PATH)
assert spec is not None and spec.loader is not None
workflow_module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = workflow_module
spec.loader.exec_module(workflow_module)

OrchestratorState = workflow_module.OrchestratorState
OrchestratorWorkflow = workflow_module.OrchestratorWorkflow

graph_spec = importlib.util.spec_from_file_location("orchestrator_graph_runtime", GRAPH_PATH)
assert graph_spec is not None and graph_spec.loader is not None
graph_module = importlib.util.module_from_spec(graph_spec)
sys.modules[graph_spec.name] = graph_module
graph_spec.loader.exec_module(graph_module)

OrchestratorGraph = graph_module.OrchestratorGraph


def test_initial_state_is_idle_and_valid():
    # A fresh state should be empty and not yet assigned to a working stage.
    state = OrchestratorState()

    assert state.status == "idle"
    assert state.history == []
    assert state.next_stage is None


def test_workflow_advances_through_eval_stages():
    # The job should move through the initial queue and then into a stage.
    workflow = OrchestratorWorkflow()
    state = workflow.start_job(job_id="job-123", source="demo")

    assert state.job_id == "job-123"
    assert state.status == "queued"
    assert state.next_stage == "precheck"

    state = workflow.run_stage(state, "precheck")
    assert state.status == "running"
    assert state.current_stage == "precheck"

    state = workflow.run_stage(state, "quality_gate")
    assert state.current_stage == "quality_gate"
    assert state.history[-1]["stage"] == "quality_gate"


def test_quality_gate_and_decision_engine():
    # A healthy output should pass the quality gate and be accepted or reviewed.
    quality_gate = OrchestratorGraph().quality_gate

    state = {
        "quality_score": 0.85,
        "degradation_score": 0.20,
        "hallucination_risk": 0.08,
    }
    assert quality_gate(state) is True

    decision = OrchestratorGraph().decide(
        quality_score=0.82,
        degradation_score=0.22,
        hallucination_risk=0.1,
    )
    assert decision in {"accept", "review"}


def test_worker_dispatch_is_threshold_based():
    graph = OrchestratorGraph()

    metrics = {
        "haze": 0.82,
        "missing_data": 0.12,
        "resolution": 0.91,
        "low_light": 0.20,
        "uncertainty": 0.65,
    }

    workers = graph.dispatch_workers(metrics)

    assert "dehazing" in workers
    assert "superres_fusion" in workers
    assert "confidence_map" in workers
    assert "inpainting" not in workers
    assert "planetary_domain" not in workers


def run_smoke_checks():
    test_initial_state_is_idle_and_valid()
    test_workflow_advances_through_eval_stages()
    test_quality_gate_and_decision_engine()
    test_worker_dispatch_is_threshold_based()
    print("orchestrator smoke checks passed")


if __name__ == "__main__":
    run_smoke_checks()
