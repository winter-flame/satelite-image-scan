"""Crater / terrain / hazard validation model.

This is a validation/scoring model, not a pixel-correcting worker. It computes a
proof-of-value metric by comparing crater and hazard detections before vs after
enhancement.
"""

from __future__ import annotations


def _detections(tile, metadata, key):
    detector = metadata.get("detector") if metadata else None
    if detector is not None:
        return list(detector(tile, metadata))
    return list((metadata or {}).get(key, []))


def _f1(predictions, truth, tolerance=3.0):
    if not truth and not predictions:
        return 1.0
    if not truth or not predictions:
        return 0.0
    matched = set()
    true_positives = 0
    for prediction in predictions:
        for index, expected in enumerate(truth):
            if index in matched:
                continue
            distance = abs(float(prediction["x"]) - float(expected["x"])) + abs(
                float(prediction["y"]) - float(expected["y"])
            )
            if distance <= tolerance:
                matched.add(index)
                true_positives += 1
                break
    precision = true_positives / len(predictions)
    recall = true_positives / len(truth)
    return 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0


def crater_hazard_validate(original_tile, enhanced_tile, ground_truth=None, proxy_score=None, metadata=None):
    """Detect both tiles and return the downstream proof-of-value F1 delta."""
    if ground_truth is not None:
        original_detections = _detections(original_tile, metadata, "original_detections")
        enhanced_detections = _detections(enhanced_tile, metadata, "enhanced_detections")
        f1_original = _f1(original_detections, ground_truth)
        f1_enhanced = _f1(enhanced_detections, ground_truth)
    else:
        original_score = float(proxy_score if proxy_score is not None else 0.0)
        enhanced_score = float((metadata or {}).get("enhanced_proxy_score", original_score))
        f1_original = max(0.0, min(1.0, original_score))
        f1_enhanced = max(0.0, min(1.0, enhanced_score))

    return {
        "f1_original": f1_original,
        "f1_enhanced": f1_enhanced,
        "f1_delta": f1_enhanced - f1_original,
        "metric_name": "crater_detection_f1_delta",
    }
