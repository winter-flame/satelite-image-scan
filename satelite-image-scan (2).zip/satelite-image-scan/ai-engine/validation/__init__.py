"""Validation and scientific proof models for the member 4 surface."""

from .crater_detection import crater_hazard_validate

__all__ = ["crater_hazard_validate"]
