"""AI engine package for the satellite image enhancement pipeline.

This package is the member 3 surface of the repo: it owns the orchestration
control plane for the satellite image enhancement workflow. In other words,
this is where we decide what work should run, when it should run, and whether
an output is good enough to accept.
"""
