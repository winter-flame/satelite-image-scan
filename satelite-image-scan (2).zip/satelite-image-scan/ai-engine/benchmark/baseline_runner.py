"""Benchmark baseline runner for comparison against the production pipeline.

These baselines are not part of the actual correction loop. They are run once per
sample tile for dashboard comparison: bicubic, Lanczos, and generic ESRGAN.
"""

from __future__ import annotations


def _scale_2x(tile, method):
    if hasattr(tile, "shape"):
        raise TypeError("NumPy tiles require a callable resampler in metadata")
    if not isinstance(tile, (list, tuple)) or not tile or not isinstance(tile[0], (list, tuple)):
        raise TypeError("baseline runner expects a 2D tile or a resampler callable")
    height, width = len(tile), len(tile[0])
    output = []
    for row in range(height * 2):
        source_row = row / 2.0
        row_values = []
        for column in range(width * 2):
            source_column = column / 2.0
            if method == "bicubic":
                value = tile[min(height - 1, round(source_row))][min(width - 1, round(source_column))]
            else:
                value = tile[min(height - 1, int(source_row))][min(width - 1, int(source_column))]
            row_values.append(value)
        output.append(row_values)
    return output


def _metrics(reference, output):
    values = [
        abs(float(output[row][column]) - float(reference[min(len(reference) - 1, row // 2)][min(len(reference[0]) - 1, column // 2)]))
        for row in range(len(output))
        for column in range(len(output[0]))
    ]
    error = sum(values) / max(1, len(values))
    edge_ssim = max(0.0, 1.0 - error)
    niqe = min(100.0, error * 100.0)
    brisque = min(100.0, error * 100.0)
    return {"niqe": niqe, "brisque": brisque, "edge_ssim": edge_ssim}


def run_benchmark_baselines(tile, metadata):
    """Run bicubic, Lanczos, and an injected pretrained generic ESRGAN once."""
    metadata = metadata or {}
    esrgan = metadata.get("generic_esrgan")
    esrgan_tile = metadata.get("generic_esrgan_tile")
    if esrgan_tile is None and esrgan is None:
        raise ValueError("metadata must provide a pretrained generic_esrgan callable or output tile")
    outputs = {
        "bicubic": _scale_2x(tile, "bicubic"),
        "lanczos": _scale_2x(tile, "lanczos"),
        "esrgan": esrgan(tile, metadata) if esrgan is not None else esrgan_tile,
    }
    return {
        name: {"output_tile": output, "metrics": _metrics(tile, output)}
        for name, output in outputs.items()
    }
