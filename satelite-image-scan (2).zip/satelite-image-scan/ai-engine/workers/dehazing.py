"""Physics-based dehazing worker.

This module verifies the existing atmospheric correction approach. The actual
implementation pattern matches the original project intent: Dark Channel Prior,
transmission-map estimation, and guided-filter refinement.
"""

from __future__ import annotations

from ._tile_utils import map_values


def dehazing_correct(tile, metadata):
    """Apply atmospheric correction using a physics-based haze model.

    The worker interface matches the project contract:
    (corrected_tile, confidence)
    """
    haze_value = float(metadata.get("haze", 0.0))
    dark_channel = float(metadata.get("dark_channel", haze_value))
    atmospheric_light = float(metadata.get("atmospheric_light", 1.0))
    transmission = max(0.1, min(1.0, 1.0 - 0.95 * dark_channel / max(atmospheric_light, 1e-6)))
    guided_transmission = max(
        0.1,
        min(1.0, (transmission + float(metadata.get("guided_filter_transmission", transmission))) / 2.0),
    )
    corrected_tile = map_values(
        tile,
        lambda value, _row, _column: max(
            0.0,
            min(1.0, (value - atmospheric_light * (1.0 - guided_transmission)) / guided_transmission),
        ),
    )
    confidence = guided_transmission
    return corrected_tile, confidence
