"""Cloud and shadow inpainting worker.

This verifies the multi-temporal reference logic: prefer cloud-free reference
passes when available, then use a classical or deep fallback if there is no good
reference tile.
"""

from __future__ import annotations

from ._tile_utils import blend_tiles, copy_tile


def inpainting_correct(tile, metadata):
    """Fill missing cloud/shadow regions using a reference pass when available."""
    missing_ratio = float(metadata.get("missing_data", 0.0))
    has_reference = bool(metadata.get("reference_pass_available", False))

    corrected_tile = copy_tile(tile)
    if has_reference:
        reference_tile = metadata.get("reference_tile")
        if reference_tile is not None:
            corrected_tile = blend_tiles(tile, reference_tile, min(1.0, missing_ratio))
        confidence = 0.85 if missing_ratio <= 0.4 else 0.7
    else:
        fallback_tile = metadata.get("fallback_tile")
        if fallback_tile is not None:
            corrected_tile = blend_tiles(tile, fallback_tile, min(0.8, missing_ratio))
        confidence = 0.6 if missing_ratio <= 0.5 else 0.45
    return corrected_tile, confidence
