"""Planetary/lunar domain correction worker.

This worker is separate from crater/terrain detection. It corrects image
artifacts specific to planetary imagery such as crater rims, regolith texture,
permanently shadowed regions (PSRs), and steep terrain shading.
"""

from __future__ import annotations

from ._tile_utils import blend_tiles, copy_tile, map_values


def planetary_domain_correct(tile, metadata):
    """Correct planetary domain degradation while preserving low-confidence on PSRs.

    Returns a (corrected_tile, confidence) tuple.
    """
    low_light = float(metadata.get("low_light", 0.0))
    shadowed_pixels = float(metadata.get("psr_ratio", 0.0))
    has_multiview = bool(metadata.get("multi_view_available", False))
    albedo_prior = float(metadata.get("albedo_prior", 0.5))

    corrected_tile = copy_tile(tile)

    # Heavily shadowed pixels should not be brightened blindly. Instead, we rely
    # on available multi-angle or albedo priors and mark inferred content as low
    # confidence rather than inventing nonexistent terrain.
    if shadowed_pixels > 0.4:
        reference_tile = metadata.get("multi_angle_tile")
        if reference_tile is None:
            reference_tile = metadata.get("albedo_prior_tile")
        if reference_tile is not None:
            corrected_tile = blend_tiles(tile, reference_tile, float(metadata.get("inferred_weight", 0.25)))
        confidence = 0.35 if not has_multiview else 0.5
    elif low_light > 0.6:
        illumination = max(0.25, float(metadata.get("illumination_gain", 1.0)))
        corrected_tile = map_values(tile, lambda value, _row, _column: value * illumination)
        confidence = 0.6 if albedo_prior > 0.4 else 0.5
    else:
        confidence = 0.8

    return corrected_tile, confidence
