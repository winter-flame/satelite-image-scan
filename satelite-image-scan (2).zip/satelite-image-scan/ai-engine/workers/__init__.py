"""Correction workers for member 4.

Each worker follows the project contract pattern:
    worker_name(tile, metadata) -> (corrected_tile, confidence)
"""

from .confidence_map import generate_confidence_map
from .dehazing import dehazing_correct
from .inpainting import inpainting_correct
from .planetary_domain import planetary_domain_correct
from .superres_fusion import superres_fusion_correct
from .ensemble import run_worker_ensemble

__all__ = [
    "dehazing_correct",
    "inpainting_correct",
    "superres_fusion_correct",
    "planetary_domain_correct",
    "generate_confidence_map",
    "run_worker_ensemble",
]
