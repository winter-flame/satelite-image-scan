"""Confidence map generation for corrected tiles.

This keeps the per-pixel categorical structure:
0 = untouched
1 = physically recovered
2 = temporally recovered
3 = inferred

It also adds an auditable evidence breakdown stored alongside the raster in a
small dict-like payload rather than embedding per-pixel explanations.
"""

from __future__ import annotations

from ._tile_utils import tile_shape, zeros_like


def generate_confidence_map(tile, metadata):
    """Create a categorical confidence map and attach evidence metadata."""
    confidence_map = metadata.get("category_map")
    if confidence_map is None:
        confidence_map = zeros_like(tile)
    shape = tile_shape(confidence_map)
    evidence = {
        "version": "1",
        "categories": {
            "1": {"meaning": "physically recovered", "sources": metadata.get("physical_sources", [])},
            "2": {"meaning": "temporally recovered", "sources": metadata.get("temporal_sources", [])},
            "3": {"meaning": "inferred", "sources": metadata.get("inferred_sources", [])},
        },
        "tile_shape": list(shape),
        "records": metadata.get("evidence_records", []),
    }
    return confidence_map, evidence
