"""Super-resolution and fusion worker.

The project spec prefers pansharpen fusion when a panchromatic band is present.
Single-image SR is a guarded fallback, and SR-only outputs are marked with lower
confidence.
"""

from __future__ import annotations

from ._tile_utils import blend_tiles, copy_tile


def superres_fusion_correct(tile, metadata):
    """Apply pan-sharpen or single-image SR depending on available input bands."""
    has_pan = bool(metadata.get("has_panchromatic", False))
    sr_only = not has_pan

    corrected_tile = copy_tile(tile)
    if has_pan:
        pan_tile = metadata.get("panchromatic_tile")
        if pan_tile is not None:
            corrected_tile = blend_tiles(tile, pan_tile, float(metadata.get("pan_fusion_weight", 0.5)))
        confidence = 0.9
    elif sr_only:
        sr_tile = metadata.get("sr_tile")
        if sr_tile is not None:
            corrected_tile = copy_tile(sr_tile)
        confidence = 0.6
    return corrected_tile, confidence
