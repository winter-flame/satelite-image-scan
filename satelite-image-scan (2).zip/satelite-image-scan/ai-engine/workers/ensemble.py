"""Common candidate generation for correction workers."""

from __future__ import annotations

from .dehazing import dehazing_correct
from .inpainting import inpainting_correct
from .planetary_domain import planetary_domain_correct
from .superres_fusion import superres_fusion_correct


WORKER_FUNCTIONS = {
    "dehazing": dehazing_correct,
    "inpainting": inpainting_correct,
    "superres_fusion": superres_fusion_correct,
    "planetary_domain": planetary_domain_correct,
}


def run_worker_ensemble(worker_name, tile, metadata, variant_count=3):
    """Generate and score 2-3 candidates; selection remains an orchestrator job."""
    if worker_name not in WORKER_FUNCTIONS:
        raise KeyError(f"No ensemble worker registered for {worker_name!r}")
    if variant_count not in (2, 3):
        raise ValueError("variant_count must be 2 or 3")

    worker = WORKER_FUNCTIONS[worker_name]
    variants = []
    for index in range(variant_count):
        variant_metadata = dict(metadata)
        configured_variants = metadata.get("variants", [])
        if index < len(configured_variants):
            variant_metadata.update(configured_variants[index])
        variant_metadata["variant_index"] = index
        corrected_tile, confidence = worker(tile, variant_metadata)
        variants.append({
            "variant_index": index,
            "tile": corrected_tile,
            "confidence": float(confidence),
            "score": float(confidence),
        })
    return {"worker": worker_name, "variants": variants}
