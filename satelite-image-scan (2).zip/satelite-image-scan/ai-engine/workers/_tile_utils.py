"""Small array helpers shared by correction workers.

Production tiles are normally rasterio/NumPy arrays shaped (bands, rows, cols)
or (rows, cols). Nested Python lists are supported for lightweight tests.
"""

from __future__ import annotations

from copy import deepcopy


def copy_tile(tile):
    return tile.copy() if hasattr(tile, "copy") else deepcopy(tile)


def tile_shape(tile) -> tuple[int, ...]:
    if hasattr(tile, "shape"):
        return tuple(int(value) for value in tile.shape)
    if not isinstance(tile, (list, tuple)) or not tile:
        raise TypeError("tile must be a non-empty 2D or 3D array-like value")
    if isinstance(tile[0], (list, tuple)) and tile[0] and isinstance(tile[0][0], (list, tuple)):
        return len(tile), len(tile[0]), len(tile[0][0])
    return len(tile), len(tile[0])


def zeros_like(tile):
    if hasattr(tile, "shape"):
        try:
            return tile * 0
        except TypeError:
            pass
    shape = tile_shape(tile)
    if len(shape) == 2:
        return [[0 for _ in range(shape[1])] for _ in range(shape[0])]
    return [[[0 for _ in range(shape[2])] for _ in range(shape[1])] for _ in range(shape[0])]


def map_values(tile, transform):
    result = copy_tile(tile)
    shape = tile_shape(tile)
    if len(shape) == 2:
        for row in range(shape[0]):
            for column in range(shape[1]):
                result[row][column] = transform(tile[row][column], row, column)
    else:
        for band in range(shape[0]):
            for row in range(shape[1]):
                for column in range(shape[2]):
                    result[band][row][column] = transform(tile[band][row][column], row, column)
    return result


def blend_tiles(primary, reference, weight: float):
    weight = max(0.0, min(1.0, weight))
    return map_values(
        primary,
        lambda value, row, column: value * (1.0 - weight) + reference[row][column] * weight,
    )
