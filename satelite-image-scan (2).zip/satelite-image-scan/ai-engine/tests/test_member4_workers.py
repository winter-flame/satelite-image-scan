import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "ai-engine"))

from benchmark.baseline_runner import run_benchmark_baselines
from orchestrator.metrics.scoring import DegradationScorer
from validation.crater_detection import crater_hazard_validate
from workers import generate_confidence_map, run_worker_ensemble


def test_degradation_score_is_low_for_good_quality():
    scorer = DegradationScorer()
    assert scorer.score(edge_ssim=0.95, niqe=5, brisque=5) < 0.35
    assert scorer.score(edge_ssim=0.2, niqe=80, brisque=80) > 0.7


def test_confidence_map_keeps_categories_and_evidence():
    tile = [[1, 2], [3, 4]]
    category_map, evidence = generate_confidence_map(
        tile,
        {"category_map": [[0, 1], [2, 3]], "temporal_sources": ["pass-7"]},
    )
    assert category_map == [[0, 1], [2, 3]]
    assert evidence["categories"]["2"]["sources"] == ["pass-7"]


def test_crater_validation_uses_original_and_enhanced_f1():
    truth = [{"x": 2, "y": 2}]
    result = crater_hazard_validate(
        [[0]],
        [[0]],
        ground_truth=truth,
        metadata={
            "original_detections": [],
            "enhanced_detections": [{"x": 2, "y": 2}],
        },
    )
    assert result["f1_delta"] == 1.0


def test_planetary_worker_uses_common_ensemble():
    result = run_worker_ensemble("planetary_domain", [[0.2]], {"psr_ratio": 0.8}, variant_count=2)
    assert len(result["variants"]) == 2
    assert all(variant["score"] < 0.6 for variant in result["variants"])


def test_baselines_return_outputs_and_metrics():
    result = run_benchmark_baselines([[0.1, 0.2], [0.3, 0.4]], {"generic_esrgan_tile": [[0.1] * 4] * 4})
    assert set(result) == {"bicubic", "lanczos", "esrgan"}
    assert set(result["bicubic"]["metrics"]) == {"niqe", "brisque", "edge_ssim"}