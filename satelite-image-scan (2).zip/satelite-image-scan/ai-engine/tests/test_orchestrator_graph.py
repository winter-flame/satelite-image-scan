# These tests exercise the orchestration control plane in a lightweight way.
# They confirm the job lifecycle, stage progression, and final quality decision
# logic behave as expected before the team adds the real worker integration.
import importlib
import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
GRAPH_PATH = ROOT / "ai-engine" / "orchestrator" / "graph" / "graph.py"

graph_spec = importlib.util.spec_from_file_location("orchestrator_graph_runtime", GRAPH_PATH)
assert graph_spec is not None and graph_spec.loader is not None
graph_module = importlib.util.module_from_spec(graph_spec)
sys.modules[graph_spec.name] = graph_module
graph_spec.loader.exec_module(graph_module)

OrchestratorGraph = graph_module.OrchestratorGraph
OrchestratorGraphState = graph_module.OrchestratorGraphState


def test_initial_state_is_idle_and_valid():
    # A fresh state should be empty and not yet assigned to a working stage.
    state = OrchestratorGraphState()

    assert state.status == "idle"
    assert state.history == []
    assert state.next_stage is None


def test_graph_tracks_a_closed_loop_job():
    graph = OrchestratorGraph()
    state = graph.start_job(job_id="job-123", tile=[[0.5]], metadata={"haze": 0.8})

    assert state.job_id == "job-123"
    assert state.status == "running"
    assert state.current_stage == "assess"
    assert state.history[-1]["stage"] == "assess"


def test_quality_gate_and_decision_engine():
    # A healthy output should pass the quality gate and be accepted or reviewed.
    quality_gate = OrchestratorGraph().quality_gate

    state = {
        "quality_score": 0.85,
        "degradation_score": 0.20,
        "hallucination_risk": 0.08,
    }
    assert quality_gate(state) is True

    decision = OrchestratorGraph().decide(
        quality_score=0.82,
        degradation_score=0.22,
        hallucination_risk=0.1,
    )
    assert decision in {"accept", "review"}


def test_worker_dispatch_is_threshold_based_and_sequential():
    """Dispatch returns one fixed-order worker, with reassessment between stages."""
    graph = OrchestratorGraph()

    metrics = {
        "haze": 0.82,
        "missing_data": 0.12,
        "resolution": 0.91,
        "low_light": 0.20,
        "uncertainty": 0.65,
    }

    first_worker = graph.dispatch_workers(metrics)
    second_worker = graph.dispatch_workers(metrics, completed_workers=[first_worker])

    assert first_worker == "dehazing"
    assert second_worker == "superres_fusion"


def run_smoke_checks():
    test_initial_state_is_idle_and_valid()
    test_graph_tracks_a_closed_loop_job()
    test_quality_gate_and_decision_engine()
    test_worker_dispatch_is_threshold_based_and_sequential()
    print("orchestrator smoke checks passed")


if __name__ == "__main__":
    run_smoke_checks()
