from __future__ import annotations


# These metric helpers are the numerical interpretation layer of the AI
# orchestrator. They convert raw quality indicators into score values the gate
# and decision engine can reason about.
class QualityMetrics:
    """Utilities for quality scoring and degradation checks."""

    def compute_quality(
        self,
        *,
        quality_score: float,
        degradation_score: float,
        hallucination_risk: float,
    ) -> dict[str, float]:
        # Normalize the numeric values so the rest of the workflow gets consistent
        # score objects regardless of the upstream source.
        return {
            "quality_score": float(quality_score),
            "degradation_score": float(degradation_score),
            "hallucination_risk": float(hallucination_risk),
        }


class DegradationScorer:
    """Estimate a normalized degradation score from image-quality metrics.

    NOTE: In this pipeline, a lower degradation score means better quality. The
    quality gate interprets small degradation values as healthy, so the scorer must
    invert the "quality-is-good" signal before returning a degradation score.
    """

    def score(
        self,
        *,
        edge_ssim: float,
        niqe: float,
        brisque: float,
        niqe_max: float = 100.0,
        brisque_max: float = 100.0,
    ) -> float:
        """Return degradation in the gate's direction: lower means better."""
        normalized_edge_ssim = max(0.0, min(1.0, float(edge_ssim)))
        normalized_niqe = max(0.0, min(1.0, float(niqe) / max(niqe_max, 1e-9)))
        normalized_brisque = max(0.0, min(1.0, float(brisque) / max(brisque_max, 1e-9)))
        quality_component = (
            normalized_edge_ssim * 0.5
            + (1.0 - normalized_niqe) * 0.25
            + (1.0 - normalized_brisque) * 0.25
        )
        degradation_score = 1.0 - quality_component
        return float(max(0.0, min(1.0, degradation_score)))


class HallucinationDetector:
    """Estimate how likely an output contains invented features or artifacts."""

    def detect(self, *, confidence_map: float, artifact_ratio: float) -> float:
        # A higher artifact ratio or lower confidence increases hallucination risk.
        return float(max(0.0, min(1.0, (1.0 - confidence_map) * 0.6 + artifact_ratio * 0.4)))
