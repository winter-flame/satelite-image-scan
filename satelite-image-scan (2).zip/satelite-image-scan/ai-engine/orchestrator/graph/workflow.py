"""Deprecated compatibility aliases for the merged orchestrator graph."""

try:
	from .graph import OrchestratorGraph, OrchestratorGraphState
except ImportError:
	import sys
	from pathlib import Path

	graph_directory = str(Path(__file__).resolve().parent)
	if graph_directory not in sys.path:
		sys.path.insert(0, graph_directory)
	from graph import OrchestratorGraph, OrchestratorGraphState

OrchestratorWorkflow = OrchestratorGraph
OrchestratorState = OrchestratorGraphState

__all__ = ["OrchestratorGraph", "OrchestratorGraphState", "OrchestratorWorkflow", "OrchestratorState"]
