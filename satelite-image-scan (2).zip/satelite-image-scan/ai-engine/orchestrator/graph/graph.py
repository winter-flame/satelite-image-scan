from __future__ import annotations

import importlib
import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _load_module(module_name: str, relative_path: str):
    module_path = Path(__file__).resolve().parents[1] / relative_path
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


_config_module = _load_module("orchestrator_config_runtime", "config/settings.py")
_gate_module = _load_module("orchestrator_quality_gate_runtime", "gates/quality_gate.py")
_decision_module = _load_module("orchestrator_decision_runtime", "decision_engine/decision.py")
_scoring_module = _load_module("orchestrator_scoring_runtime", "metrics/scoring.py")

OrchestratorConfig = _config_module.OrchestratorConfig
QualityGate = _gate_module.QualityGate
DecisionEngine = _decision_module.DecisionEngine
DegradationScorer = _scoring_module.DegradationScorer
HallucinationDetector = _scoring_module.HallucinationDetector
QualityMetrics = _scoring_module.QualityMetrics


def _worker_registry():
    engine_root = str(Path(__file__).resolve().parents[2])
    if engine_root not in sys.path:
        sys.path.insert(0, engine_root)
    return importlib.import_module("workers.ensemble").WORKER_FUNCTIONS


@dataclass
class OrchestratorGraphState:
    job_id: str | None = None
    source: str | None = None
    status: str = "idle"
    current_stage: str | None = None
    next_stage: str | None = None
    tile: Any = None
    original_tile: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)
    previous_metrics: dict[str, Any] = field(default_factory=dict)
    completed_workers: list[str] = field(default_factory=list)
    selected_worker: str | None = None
    iteration: int = 0
    decision: str | None = None
    error: str | None = None


class OrchestratorGraph:
    """Closed-loop tile orchestrator: assess, route, correct, reassess, decide."""

    WORKER_ORDER = ("dehazing", "inpainting", "superres_fusion", "planetary_domain")

    def __init__(self, config: OrchestratorConfig | None = None):
        self.config = config or OrchestratorConfig()
        self.quality_gate = QualityGate(
            quality_threshold=self.config.quality_threshold,
            degradation_threshold=self.config.degradation_threshold,
            hallucination_threshold=self.config.hallucination_threshold,
        )
        self.decision_engine = DecisionEngine(self.config)
        self.degradation_scorer = DegradationScorer()
        self.hallucination_detector = HallucinationDetector()
        self.quality_metrics = QualityMetrics()

    def start_job(
        self,
        *,
        job_id: str,
        tile: Any = None,
        metadata: dict[str, Any] | None = None,
        source: str | None = None,
    ) -> OrchestratorGraphState:
        state = OrchestratorGraphState(
            job_id=job_id,
            source=source,
            status="running",
            tile=tile,
            original_tile=tile,
            metadata=dict(metadata or {}),
        )
        state.current_stage = "assess"
        self._record(state, "assess", {"status": "started"})
        return state

    def run(
        self,
        *,
        tile: Any,
        metadata: dict[str, Any] | None = None,
        job_id: str | None = None,
        source: str | None = None,
    ) -> OrchestratorGraphState:
        state = self.start_job(job_id=job_id or "runtime-job", tile=tile, metadata=metadata, source=source)
        self._assess(state)

        while state.iteration < self.config.max_iterations:
            if self._gate_passes(state.metrics):
                break
            worker_name = self.dispatch_workers(
                state.metrics,
                metadata=state.metadata,
                completed_workers=state.completed_workers,
            )
            if worker_name is None:
                state.status = "review_required"
                self._record(state, "route", {"reason": "no_useful_worker"})
                break

            state.selected_worker = worker_name
            state.current_stage = "correct"
            self._record(state, "correct", {"worker": worker_name, "iteration": state.iteration + 1})
            try:
                worker = _worker_registry()[worker_name]
                corrected_tile, confidence = worker(state.tile, state.metadata)
            except Exception as exc:
                state.error = str(exc)
                state.status = "review_required"
                self._record(state, "correct", {"worker": worker_name, "error": state.error})
                break

            state.tile = corrected_tile
            state.completed_workers.append(worker_name)
            state.iteration += 1
            state.metadata["worker_confidence"] = float(confidence)
            self._assess(state)

        if not self._gate_passes(state.metrics) and state.status == "running":
            state.status = "review_required"
            self._record(state, "decision", {"reason": "max_iterations"})
        state.decision = self.decide(
            quality_score=state.metrics["quality_score"],
            degradation_score=state.metrics["degradation_score"],
            hallucination_risk=state.metrics["hallucination_risk"],
        )
        state.status = "completed" if state.decision == "accept" else "review_required"
        state.current_stage = "decision"
        self._record(state, "decision", {"decision": state.decision, "iteration": state.iteration})
        return state

    def _assess(self, state: OrchestratorGraphState):
        state.current_stage = "reassess"
        metadata = state.metadata
        raw = metadata.get("metrics", metadata)
        edge_ssim = float(raw.get("edge_ssim", 0.5))
        niqe = float(raw.get("niqe", 50.0))
        brisque = float(raw.get("brisque", 50.0))
        degradation = self.degradation_scorer.score(edge_ssim=edge_ssim, niqe=niqe, brisque=brisque)
        quality = float(raw.get("quality_score", 1.0 - degradation))
        confidence = float(metadata.get("worker_confidence", raw.get("confidence_map", 0.5)))
        artifact_ratio = float(raw.get("artifact_ratio", 0.0))
        hallucination = self.hallucination_detector.detect(
            confidence_map=max(0.0, min(1.0, confidence)), artifact_ratio=artifact_ratio
        )
        state.previous_metrics = state.metrics
        quality_metrics = self.quality_metrics.compute_quality(
            quality_score=quality,
            degradation_score=degradation,
            hallucination_risk=hallucination,
        )
        state.metrics = {
            **{signal: float(metadata.get(signal, 0.0)) for signal in ("haze", "missing_data", "resolution", "low_light")},
            **quality_metrics,
        }
        self._record(state, "reassess", {"metrics": state.metrics})

    def dispatch_workers(
        self,
        metrics: dict[str, float],
        *,
        metadata: dict[str, Any] | None = None,
        completed_workers: list[str] | None = None,
    ) -> str | None:
        """Return exactly the next worker in the fixed correction order."""
        metadata = metadata or {}
        completed = set(completed_workers or [])
        planetary = bool(
            metadata.get("planetary")
            or metadata.get("planetary_imagery")
            or metadata.get("lunar")
            or metadata.get("mission_type") in {"planetary", "lunar"}
        )
        signals = {
            "dehazing": "haze",
            "inpainting": "missing_data",
            "superres_fusion": "resolution",
            "planetary_domain": "low_light",
        }
        for worker_name in self.WORKER_ORDER:
            if worker_name in completed or (worker_name == "planetary_domain" and not planetary):
                continue
            signal = signals[worker_name]
            if float(metrics.get(signal, 0.0)) >= self.config.worker_thresholds[worker_name]:
                return worker_name
        return None

    def evaluate(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> bool:
        return self.quality_gate.evaluate(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        )

    def route_next(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> str:
        return "dispatch_workers" if self.evaluate(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        ) else "review_required"

    def decide(self, *, quality_score: float, degradation_score: float, hallucination_risk: float) -> str:
        return self.decision_engine.decide(
            quality_score=quality_score,
            degradation_score=degradation_score,
            hallucination_risk=hallucination_risk,
        )

    def attach_validation_metrics(self, metrics: dict[str, float], validation_result: dict) -> dict[str, float]:
        updated_metrics = dict(metrics)
        updated_metrics["crater_detection_f1_delta"] = float(validation_result["f1_delta"])
        return updated_metrics

    def _gate_passes(self, metrics: dict[str, Any]) -> bool:
        return self.evaluate(
            quality_score=metrics["quality_score"],
            degradation_score=metrics["degradation_score"],
            hallucination_risk=metrics["hallucination_risk"],
        ) if metrics else False

    @staticmethod
    def _record(state: OrchestratorGraphState, stage: str, payload: dict[str, Any]):
        state.history.append({"stage": stage, "status": state.status, "payload": payload})
