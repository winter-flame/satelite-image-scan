from __future__ import annotations


# This gate is the first real safety filter in the orchestration pipeline.
# It checks whether a generated result is good enough to continue to the next
# stage or whether it should be routed for review or rejection.
class QualityGate:
    """Quality gate used to decide whether a worker result is acceptable."""

    def __init__(
        self,
        *,
        quality_threshold: float = 0.78,
        degradation_threshold: float = 0.35,
        hallucination_threshold: float = 0.20,
    ):
        # The thresholds are configured centrally and can be tuned per dataset.
        self.quality_threshold = quality_threshold
        self.degradation_threshold = degradation_threshold
        self.hallucination_threshold = hallucination_threshold

    def evaluate(
        self,
        *,
        quality_score: float | None = None,
        degradation_score: float | None = None,
        hallucination_risk: float | None = None,
        state: dict | None = None,
    ) -> bool:
        # Accept either explicit values or a dict-like state snapshot.
        if state is not None:
            quality_score = state.get("quality_score", quality_score)
            degradation_score = state.get("degradation_score", degradation_score)
            hallucination_risk = state.get("hallucination_risk", hallucination_risk)

        if quality_score is None or degradation_score is None or hallucination_risk is None:
            raise ValueError("quality_score, degradation_score, and hallucination_risk are required")

        # A result passes only if it is high quality, not too degraded, and not
        # likely to contain invented artifacts.
        return (
            quality_score >= self.quality_threshold
            and degradation_score <= self.degradation_threshold
            and hallucination_risk <= self.hallucination_threshold
        )

    def __call__(self, state: dict) -> bool:
        return self.evaluate(state=state)
