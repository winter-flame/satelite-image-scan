from __future__ import annotations

from typing import Any
from types import SimpleNamespace


class DecisionEngine:
    """Decide whether to accept, review, or reject a processed tile."""

    def __init__(self, config: Any | None = None):
        self.config: Any = config or SimpleNamespace(
            quality_threshold=0.78,
            degradation_threshold=0.35,
            hallucination_threshold=0.20,
            auto_reject_if_quality_below=0.65,
        )

    def decide(
        self,
        *,
        quality_score: float | None = None,
        degradation_score: float | None = None,
        hallucination_risk: float | None = None,
        state: dict | None = None,
    ) -> str:
        if state is not None:
            quality_score = state.get("quality_score", quality_score)
            degradation_score = state.get("degradation_score", degradation_score)
            hallucination_risk = state.get("hallucination_risk", hallucination_risk)

        if quality_score is None or degradation_score is None or hallucination_risk is None:
            raise ValueError("quality_score, degradation_score, and hallucination_risk are required")

        if quality_score < self.config.auto_reject_if_quality_below:
            return "reject"
        if (
            quality_score >= self.config.quality_threshold
            and degradation_score <= self.config.degradation_threshold
            and hallucination_risk <= self.config.hallucination_threshold
        ):
            return "accept"
        if quality_score >= self.config.auto_reject_if_quality_below:
            return "review"
        return "reject"
