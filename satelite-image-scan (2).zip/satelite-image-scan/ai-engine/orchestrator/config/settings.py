from dataclasses import dataclass, field


# This config file centralizes the rules the orchestrator uses while processing a
# job. These values are intentionally explicit so the team can tune thresholds
# without digging through the flow logic.
@dataclass
class OrchestratorConfig:
    """Operational thresholds for the AI orchestrator."""

    # Maximum number of attempts before a job is escalated for human review.
    max_iterations: int = 3

    # Minimum quality score required before a result is considered safe to accept.
    quality_threshold: float = 0.78

    # Maximum tolerated degradation before a result is considered too weak.
    degradation_threshold: float = 0.35

    # Maximum allowed hallucination risk before the output should not be trusted.
    hallucination_threshold: float = 0.20

    # Safety fallback used for hard rejection scenarios.
    auto_reject_if_quality_below: float = 0.65

    # Worker-specific thresholds. Each worker should only be activated when its
    # matching degradation factor exceeds the configured threshold.
    worker_thresholds: dict[str, float] = field(
        default_factory=lambda: {
            "dehazing": 0.60,
            "inpainting": 0.55,
            "superres_fusion": 0.70,
            "planetary_domain": 0.65,
            "confidence_map": 0.50,
            "crater_detection": 0.55,
        }
    )

    # Map each degradation signal to the worker that can address it.
    worker_map: dict[str, str] = field(
        default_factory=lambda: {
            "haze": "dehazing",
            "missing_data": "inpainting",
            "resolution": "superres_fusion",
            "low_light": "planetary_domain",
            "uncertainty": "confidence_map",
            "terrain_risk": "crater_detection",
        }
    )

    # Stages the orchestrator recognizes as valid workflow states.
    accepted_stages: tuple[str, ...] = (
        "precheck",
        "quality_gate",
        "model_dispatch",
        "validation",
        "decision",
    )

    # Ordered stage sequence used to advance the workflow state machine.
    stage_order: list[str] = field(
        default_factory=lambda: [
            "precheck",
            "quality_gate",
            "model_dispatch",
            "validation",
            "decision",
        ]
    )
