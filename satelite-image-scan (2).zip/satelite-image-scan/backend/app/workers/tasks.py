from __future__ import annotations

import os
import sys
import uuid
from pathlib import Path

import rasterio

from app.workers.celery_app import celery_app

UPLOAD_DIR = "uploads"
AI_ENGINE_ROOT = str(Path(__file__).resolve().parents[3] / "ai-engine")
if AI_ENGINE_ROOT not in sys.path:
    sys.path.insert(0, AI_ENGINE_ROOT)

from orchestrator.graph.graph import OrchestratorGraph


@celery_app.task(bind=True)
def process_tile_task(self, tile_filename: str):
    tile_path = os.path.join(UPLOAD_DIR, tile_filename)

    if not os.path.exists(tile_path):
        return {"tile_filename": tile_filename, "status": "error", "error": "Tile not found"}

    job_id = str(uuid.uuid4())
    with rasterio.open(tile_path) as source:
        tile = source.read()
        tags = source.tags()
        metadata = {
            "band_count": source.count,
            "width": source.width,
            "height": source.height,
            "dtype": str(source.dtypes[0]) if source.dtypes else "unknown",
            "crs": str(source.crs) if source.crs else None,
            "metrics": _read_metrics(tags),
            "haze": _read_float(tags, "HAZE", 0.0),
            "missing_data": _read_float(tags, "MISSING_DATA", 0.0),
            "resolution": _read_float(tags, "RESOLUTION_DEGRADATION", 0.0),
            "low_light": _read_float(tags, "LOW_LIGHT", 0.0),
            "planetary": tags.get("MISSION_TYPE", "").lower() in {"planetary", "lunar"},
        }
        payload = {
            "job_id": job_id,
            "tile_filename": tile_filename,
            "tile_index": 0,
            "tile_bounds": {"x": 0, "y": 0, "width": source.width, "height": source.height},
            "metadata": metadata,
            "routing": {
                "pipeline": tags.get("PIPELINE", "orchestrator"),
                "reason": "Celery task dispatched the raster tile to the orchestrator",
                "confidence": "medium",
            },
        }
        graph = OrchestratorGraph()
        state = graph.run(
            tile=tile,
            metadata={**payload["metadata"], **payload["routing"]},
            job_id=job_id,
            source=tile_filename,
        )
        output_name = f"enhanced_{tile_filename}"
        output_path = os.path.join(UPLOAD_DIR, output_name)
        output_tile = state.tile
        profile = source.profile.copy()

    with rasterio.open(output_path, "w", **profile) as destination:
        destination.write(output_tile)

    scores = {
        "niqe": float(state.metadata.get("metrics", {}).get("niqe", 50.0)),
        "brisque": float(state.metadata.get("metrics", {}).get("brisque", 50.0)),
        "edge_ssim": float(state.metadata.get("metrics", {}).get("edge_ssim", 0.5)),
        "quality_score": float(state.metrics["quality_score"]),
        "degradation_score": float(state.metrics["degradation_score"]),
        "hallucination_risk": float(state.metrics["hallucination_risk"]),
    }
    result = {
        "tile_filename": tile_filename,
        "model": state.selected_worker or "orchestrator_pipeline",
        "model_version": "member-3-orchestrator-v1",
        "iteration": state.iteration,
        "scores": scores,
        "hallucination_flag": state.metrics["hallucination_risk"] > 0.20,
        "decision": state.decision,
        "output_tile_filename": output_name,
        "history": state.history,
    }
    if "crater_detection_f1_delta" in state.metrics:
        result["crater_detection_f1_delta"] = state.metrics["crater_detection_f1_delta"]
    return result


def _read_float(tags: dict, key: str, default: float) -> float:
    try:
        return float(tags.get(key, default))
    except (TypeError, ValueError):
        return default


def _read_metrics(tags: dict) -> dict[str, float]:
    return {
        "edge_ssim": _read_float(tags, "EDGE_SSIM", 0.5),
        "niqe": _read_float(tags, "NIQE", 50.0),
        "brisque": _read_float(tags, "BRISQUE", 50.0),
        "artifact_ratio": _read_float(tags, "ARTIFACT_RATIO", 0.0),
    }
